import { Commande } from './commande';

describe('Commande', () => {
  it('should create an instance', () => {
    expect(new Commande()).toBeTruthy();
  });
});
