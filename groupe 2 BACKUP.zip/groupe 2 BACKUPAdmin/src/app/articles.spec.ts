import { Articles } from './articles';

describe('Articles', () => {
  it('should create an instance', () => {
    expect(new Articles()).toBeTruthy();
  });
});
