export class Articles {
    idArticle: number;
    nom: string;
    description:string;
    categorie: string;
    prix: number;
    image:string;
    quantite: number; 

}