import { LigneCommande } from './ligne-commande';

describe('LigneCommande', () => {
  it('should create an instance', () => {
    expect(new LigneCommande()).toBeTruthy();
  });
});
