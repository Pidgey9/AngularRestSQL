export class Utilisateur {
    login:string ;
    password:string;
    nom:string;
    prenom:string;
    adresse:string;
    isAdmin:boolean;
    date_naissance:Date;
    e_mail:string;
}
