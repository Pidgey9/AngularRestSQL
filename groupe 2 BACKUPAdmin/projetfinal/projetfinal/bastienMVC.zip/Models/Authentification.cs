using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace projetfinal.Models
{
  
    public class Authentification
    {
      public string login { get; set; }
      public string password { get; set; }
    }
  
}
